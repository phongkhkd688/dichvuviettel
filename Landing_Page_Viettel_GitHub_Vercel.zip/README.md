# Đưa landing page Viettel lên GitHub Pages và Vercel

## Tệp đưa lên GitHub

1. Giải nén ZIP. Đưa **các tệp bên trong thư mục `public`** vào thư mục gốc của repository GitHub, gồm `index.html` và `.nojekyll`. Tệp bắt đầu bằng dấu chấm có thể bị ẩn khi duyệt thư mục.
2. GitHub Pages: vào **Settings → Pages → Deploy from a branch**, chọn **main → /(root)** rồi lưu. Mở URL do GitHub Pages hiển thị.
3. Vercel: chọn **Add New → Project**, import cùng repository, chọn **Framework Preset → Other**, giữ **Root Directory** ở thư mục gốc và để trống lệnh build, sau đó chọn **Deploy**. Mở URL dự án Vercel.

Trang dùng CSS và JavaScript nhúng trong `index.html`. Ảnh minh họa và video tải từ Tendoo và YouTube khi có mạng.

## Bật form Google Sheets và email

1. Dùng `apps-script/Code.gs` và `apps-script/Index.html` để triển khai Google Apps Script theo `apps-script/HUONG_DAN.md`. Chạy cài đặt bằng tài khoản chủ bảng tính.
2. Trong Apps Script, sao chép URL **Web app** công khai có dạng `https://script.google.com/macros/s/…/exec`.
3. Mở `index.html`, tìm `const APPS_SCRIPT_URL = '';` và dán URL vào giữa hai dấu nháy. Commit lại lên GitHub.
4. Mở URL công khai của landing page bằng cửa sổ ẩn danh. Nút **Mở form đăng ký** dẫn đến web app, nơi khách chọn giải pháp, điền thông tin và nhận popup. Email xác nhận, nhắc Zoom và lưu Google Sheets chạy trong Apps Script. Khi chưa nhập URL web app, trang có nút chat Zalo.

Ảnh cá nhân và QR thanh toán chưa có trong gói. Bổ sung vào web app qua các thuộc tính ảnh và thông tin người nhận đã nêu trong hướng dẫn Apps Script.

- [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [Vercel Builds](https://vercel.com/docs/builds)
- [Google Apps Script Web apps](https://developers.google.com/apps-script/guides/web)
