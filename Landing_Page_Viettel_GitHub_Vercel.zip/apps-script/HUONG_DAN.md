# Landing page Giải pháp chuyển đổi số Viettel

## Cài đặt

1. Tạo một Google Sheet riêng để nhận đăng ký. Lấy ID giữa `/d/` và `/edit` trong địa chỉ bảng tính. Không chia sẻ bảng này cho khách.
2. Từ bảng tính mở **Extensions → Apps Script**. Dán toàn bộ `Code.gs` vào tệp Code.gs. Tạo tệp HTML tên **Index**, rồi dán toàn bộ `Index.html`.
3. Trong **Project Settings → Script properties**, thêm các mục bên dưới. Đặt múi giờ project là **Asia/Ho_Chi_Minh**. Tên thuộc tính phân biệt hoa thường.

| Thuộc tính | Giá trị |
| --- | --- |
| `SHEET_ID` | ID Google Sheet, bắt buộc |
| `ZALO_GROUP_URL` | Link mời HTTPS của nhóm Zalo, bắt buộc. Kiểm tra với tài khoản ngoài nhóm. Số Zalo cá nhân dùng cho nút chat và đã được cài riêng |
| `ADVISOR_NAME` | Tên hiển thị chính xác của người tư vấn, tùy chọn |
| `PORTRAIT_URL` | URL HTTPS trực tiếp tới ảnh cá nhân gốc, tùy chọn |
| `PAYMENT_QR_URL` | URL HTTPS trực tiếp tới QR gốc |
| `PAYMENT_RECIPIENT` | Tên người nhận đúng như trên QR |
| `PAYMENT_DETAILS` | Nội dung cần hiện bên dưới QR, chẳng hạn ngân hàng và số tài khoản đúng như QR |

URL ảnh cần mở được trong cửa sổ ẩn danh và trả về hình ảnh trực tiếp. Thẻ thanh toán chỉ hiện khi đủ cả ba thuộc tính PAYMENT. Đối chiếu ảnh, tên và thông tin người nhận bằng ứng dụng ngân hàng trước khi phổ biến. QR chỉ để hiển thị. Form không thu tiền và không xác minh giao dịch.

4. Trong trình chỉnh sửa, chọn **setupProject_**, bấm **Run** và cấp quyền. Chỉ định một chủ tài khoản chạy cài đặt. Hàm tạo ba tab và tạo trigger chạy mỗi phút. Có thể chạy lại để bổ sung cấu hình mà không xóa dữ liệu hiện có.
5. Chọn **Deploy → New deployment → Web app**. Chọn **Execute as → Me**, **Who has access → Anyone** nếu tài khoản cho phép, rồi bấm **Deploy**. Sao chép URL kết thúc bằng `/exec` và gửi link đó cho khách. Khi sửa mã, vào **Manage deployments → Edit → New version → Deploy**. Thay đổi Script properties áp dụng khi trang được tải lại.

## Nhập lịch Zoom

Trong tab `LichZoom`, nhập một hàng cho mỗi buổi. Cột giờ phải là giá trị ngày giờ của Sheets, theo giờ Việt Nam. Dùng mã duy nhất cho từng buổi và đánh dấu **Bật nhắc**. URL là link tham dự Zoom HTTPS, kể cả tham số mật mã nếu có.

| Mã buổi | Chủ đề | Bắt đầu (giờ VN) | Link Zoom | Bật nhắc |
| --- | --- | --- | --- | --- |
| BUOI-01 | Làm quen Tendoo và bán hàng | Nhập ngày giờ thực của buổi | Dán link tham dự thực | Tích chọn |

Hệ thống nhắm gửi vào mốc T−30 phút. Trigger không chạy chính xác tới giây, nên lượt nhắc có thể gửi muộn hơn mốc đó và luôn được kiểm tra trước giờ bắt đầu. Tất cả khách đã đồng ý và đã được gửi xác nhận có thể nhận lời nhắc của mỗi buổi đang bật. Nhật ký chống gửi lại theo mã đăng ký, mã buổi và thời điểm bắt đầu. Khi đổi giờ sau khi đã gửi, giờ mới được xem là một lượt nhắc mới. Giữ tab nhật ký để tránh gửi lại ngoài ý muốn.

## Chạy thử trước khi công bố

- Mở URL `/exec` ở cửa sổ ẩn danh. Chọn giải pháp từ thẻ sản phẩm, điền form bằng email thử và kiểm tra popup.
- Kiểm tra hàng mới ở `DangKy` và email có nút vào đúng nhóm. `PENDING` nghĩa là hệ thống sẽ thử lại. `SENT` nghĩa là Google đã chấp nhận lệnh gửi.
- Nhập một buổi thử bắt đầu sau 10–15 phút và bật nhắc. Kiểm tra email Zoom, đối chiếu nhật ký, sau đó bỏ bật nhắc buổi thử.
- Khi khách yêu cầu dừng nhận nhắc, bỏ tích **Đồng ý liên hệ** ở đúng hàng trong `DangKy`. Nếu sắp chạm hạn mức, xem **Executions** và [hạn mức Apps Script](https://developers.google.com/apps-script/guides/services/quotas). Xác nhận và lời nhắc cùng dùng hạn mức của tài khoản triển khai.
- `Landing_Page_Viettel.html` là bản xem giao diện. Form gửi dữ liệu khi mở trang web app `/exec`.

Tài liệu Google: [Triển khai web app](https://developers.google.com/apps-script/guides/web) · [Trigger theo thời gian](https://developers.google.com/apps-script/guides/triggers/installable) · [MailApp](https://developers.google.com/apps-script/reference/mail/mail-app).
