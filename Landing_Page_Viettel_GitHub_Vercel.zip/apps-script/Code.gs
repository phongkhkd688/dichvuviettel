const TZ = 'Asia/Ho_Chi_Minh';
const PRODUCTS = [
  {id:'tendoo', name:'Tendoo', type:'Quản lý bán hàng', text:'Theo dõi đơn hàng, tồn kho và doanh thu trên một nền tảng.', url:'https://tendoo.vn/', icon:'🛍️'},
  {id:'ca', name:'Viettel-CA', type:'Chữ ký số', text:'Ký số hồ sơ và chứng từ điện tử theo quy trình của doanh nghiệp.', url:'https://sme.viettel.vn/', icon:'✍️'},
  {id:'contract', name:'vContract', type:'Hợp đồng điện tử', text:'Tạo, gửi ký và theo dõi tiến độ hợp đồng trực tuyến.', url:'https://shop.viettel.vn/v-contract', icon:'📑'},
  {id:'invoice', name:'SInvoice', type:'Hóa đơn điện tử', text:'Lập, phát hành và quản lý hóa đơn điện tử.', url:'https://sme.viettel.vn/market-place/detail/SINVOICE', icon:'🧾'},
  {id:'bhxh', name:'vBHXH', type:'Kê khai BHXH', text:'Lập và quản lý hồ sơ bảo hiểm xã hội điện tử cho đơn vị.', url:'https://sme.viettel.vn/market-place/detail/VBHXH', icon:'🛡️'}
];
const VIDEOS = [
  {id:'CXnZLTpXrwQ', title:'Khám phá nền tảng Tendoo'},
  {id:'PtaRzkcXg4A', title:'Thêm sản phẩm vào cửa hàng'}
];

function config_() {
  const p = PropertiesService.getScriptProperties().getProperties();
  return {
    sheetId:p.SHEET_ID || '',
    zaloGroup:verifiedUrl_(p.ZALO_GROUP_URL, /^(zalo\.me|zalo\.im)$/i),
    photo:verifiedUrl_(p.PORTRAIT_URL),
    qr:verifiedUrl_(p.PAYMENT_QR_URL),
    advisor:(p.ADVISOR_NAME || '').trim(),
    payee:(p.PAYMENT_RECIPIENT || '').trim(),
    paymentDetails:(p.PAYMENT_DETAILS || '').trim(),
    phone:'0332 038 038',
    zalo:'https://zalo.me/0332038038'
  };
}

function doGet() {
  const c = config_();
  const page = HtmlService.createTemplateFromFile('Index');
  page.products = PRODUCTS;
  page.videos = VIDEOS;
  page.publicInfo = {
    photo:c.photo, advisor:c.advisor, phone:c.phone, zalo:c.zalo,
    qr:c.qr && c.payee && c.paymentDetails ? c.qr : '',
    payee:c.payee, paymentDetails:c.paymentDetails
  };
  return page.evaluate().setTitle('Giải pháp chuyển đổi số Viettel')
    .addMetaTag('viewport','width=device-width, initial-scale=1');
}

// Chạy từ trình chỉnh sửa bằng tài khoản chủ dự án.
function setupProject_() {
  const c = config_();
  if (!c.sheetId || !c.zaloGroup) throw new Error('Cần đặt SHEET_ID và ZALO_GROUP_URL.');
  const book = SpreadsheetApp.openById(c.sheetId);
  book.setSpreadsheetTimeZone(TZ);
  const signups = tab_(book,'DangKy',['Mã đăng ký','Thời điểm đăng ký','Họ tên','Email','Điện thoại','Đơn vị','Giải pháp','Đồng ý liên hệ','Xác nhận email']);
  signups.getRange('E2:E').setNumberFormat('@');
  signups.getRange('H2:H').setDataValidation(SpreadsheetApp.newDataValidation().requireCheckbox().build());
  const schedule = tab_(book,'LichZoom',['Mã buổi','Chủ đề','Bắt đầu (giờ VN)','Link Zoom','Bật nhắc']);
  schedule.getRange('C2:C').setNumberFormat('dd/MM/yyyy HH:mm');
  schedule.getRange('E2:E').setDataValidation(SpreadsheetApp.newDataValidation().requireCheckbox().build());
  tab_(book,'NhatKyNhac',['Khóa gửi','Mã buổi','Mã đăng ký','Trạng thái','Cập nhật']);
  const triggers = ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'runEmailQueue_');
  if (!triggers.length) ScriptApp.newTrigger('runEmailQueue_').timeBased().everyMinutes(1).create();
  triggers.slice(1).forEach(t => ScriptApp.deleteTrigger(t));
}

function submitRegistration(input) {
  input = input || {};
  const allowed = {
    name:String(input.name || '').trim(),
    email:String(input.email || '').trim().toLowerCase(),
    phone:String(input.phone || '').replace(/[ .()-]/g,''),
    company:String(input.company || '').trim(),
    products:PRODUCTS.filter(p => Array.isArray(input.products) && input.products.includes(p.id))
  };
  if (input.website || input.consent !== true || !allowed.name || allowed.name.length > 100 ||
      allowed.company.length > 160 || allowed.email.length > 150 ||
      !/^[a-z0-9][a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(allowed.email) ||
      !/^(0\d{9}|\+84\d{9})$/.test(allowed.phone) || !allowed.products.length) {
    throw new Error('Vui lòng kiểm tra họ tên, email, số điện thoại, giải pháp và ô đồng ý.');
  }
  const c = config_();
  if (!c.sheetId || !c.zaloGroup) throw new Error('Form đang được cấu hình. Vui lòng liên hệ qua Zalo.');
  if (allowed.phone.startsWith('+84')) allowed.phone = '0' + allowed.phone.slice(3);
  const labels = allowed.products.map(p => p.name + ' – ' + p.type).join(', ');
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) throw new Error('Hệ thống đang bận. Vui lòng thử lại.');
  try {
    const sheet = SpreadsheetApp.openById(c.sheetId).getSheetByName('DangKy');
    const rows = rows_(sheet,9);
    const existing = rows.findIndex(r => r[3] === allowed.email);
    if (existing >= 0) {
      const previous = rows[existing];
      if (previous[4] !== allowed.phone) throw new Error('Email này đã được đăng ký. Vui lòng kiểm tra email hoặc liên hệ Zalo.');
      const merged = PRODUCTS.map(p=>p.name+' – '+p.type).filter(label => previous[6].split(', ').includes(label) || labels.split(', ').includes(label)).join(', ');
      if (merged !== previous[6]) sheet.getRange(existing+2,7).setValue(merged);
      return {id:previous[0], products:merged, sent:previous[8] === 'SENT'};
    }
    const id = Utilities.getUuid().slice(0,12);
    const record = [id,new Date(),cell_(allowed.name),allowed.email,allowed.phone,cell_(allowed.company),labels,true,'PENDING'];
    sheet.appendRow(record);
    SpreadsheetApp.flush();
    const row = sheet.getLastRow();
    let sent = false;
    try {
      if (MailApp.getRemainingDailyQuota() > 0) {
        sendConfirmation_(record,c,allowed.name);
        sheet.getRange(row,9).setValue('SENT');
        sent = true;
      }
    } catch (err) { console.error('Confirmation pending for ' + id); }
    return {id, products:labels, sent};
  } finally {
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

function runEmailQueue_() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return;
  try {
    const c = config_();
    if (!c.sheetId || !c.zaloGroup) return;
    const book = SpreadsheetApp.openById(c.sheetId);
    const signups = book.getSheetByName('DangKy');
    const log = book.getSheetByName('NhatKyNhac');
    const registrations = rows_(signups,9);
    const logged = new Map(rows_(log,5).map((r,i) => [String(r[0]),{row:i+2,status:r[3]}]));
    const start = Date.now();
    let quota = MailApp.getRemainingDailyQuota();
    const maySend = () => quota > 0 && Date.now() - start < 22000;
    const sessions = rows_(book.getSheetByName('LichZoom'),5);
    for (const [id,title,time,url,enabled] of sessions) {
      const zoom = verifiedUrl_(url, /^(?:[a-z0-9-]+\.)*zoom\.(?:us|com)$/i);
      if (enabled !== true || !id || !title || !(time instanceof Date) || !zoom) continue;
      const scheduled = time.getTime();
      if (scheduled - start > 30*60000 || scheduled <= start) continue;
      for (const r of registrations) {
        if (!maySend() || Date.now() >= scheduled) break;
        if (!r[0] || !r[3] || r[7] !== true || r[8] !== 'SENT') continue;
        const key = JSON.stringify([String(id), r[0], scheduled]);
        const previous = logged.get(key);
        if (previous?.status === 'SENT') continue;
        try {
          sendReminder_(r,String(title),time,zoom);
        } catch (err) {
          console.error('Reminder pending for ' + r[0]);
          continue;
        }
        quota--;
        if (previous) log.getRange(previous.row,4,1,2).setValues([['SENT', new Date()]]);
        else log.appendRow([key,cell_(String(id)),r[0],'SENT',new Date()]);
        logged.set(key,{status:'SENT'});
        SpreadsheetApp.flush();
      }
    }
    registrations.forEach((r,i) => {
      if (!maySend() || r[7] !== true || r[8] !== 'PENDING') return;
      try {
        sendConfirmation_(r,c);
        quota--;
        signups.getRange(i+2,9).setValue('SENT');
      } catch (err) { console.error('Confirmation pending for ' + r[0]); }
    });
  } finally {
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

function sendConfirmation_(r,c,name) {
  mail_(r[3],'Đăng ký thành công | Giải pháp chuyển đổi số Viettel',
    'Cảm ơn bạn đã đăng ký!',
    ['Chào ' + (name || r[2]) + ',', 'Mã đăng ký: ' + r[0], 'Giải pháp bạn chọn: ' + r[6], 'Hãy tham gia nhóm Zalo để nhận hướng dẫn và theo dõi lịch học. Khi có buổi Zoom, hệ thống sẽ gửi email nhắc gần 30 phút trước giờ bắt đầu.', 'Hỗ trợ qua Zalo: ' + c.phone],
    'Tham gia nhóm Zalo',c.zaloGroup);
}

function sendReminder_(r,title,time,url) {
  const when = Utilities.formatDate(time,TZ,'HH:mm dd/MM/yyyy');
  mail_(r[3],'Nhắc lịch Zoom | ' + title,'Buổi hướng dẫn sắp bắt đầu',
    ['Chào ' + r[2] + ',', 'Chủ đề: ' + title, 'Bắt đầu: ' + when + ' (giờ Việt Nam).', 'Bạn có thể mở Zoom theo liên kết bên dưới.'],
    'Tham gia Zoom',url);
}

function mail_(to,subject,heading,paragraphs,cta,link) {
  const html = '<div style="background:#f6f3f4;padding:22px;font-family:Arial,sans-serif;color:#231a20"><div style="max-width:570px;margin:auto;background:#fff;border-radius:20px;overflow:hidden"><div style="background:#d80035;color:#fff;padding:32px"><span style="font-size:13px">GIẢI PHÁP CHUYỂN ĐỔI SỐ VIETTEL</span><h1 style="margin:10px 0 0;font-size:28px">' + esc_(heading) +
    '</h1></div><div style="padding:24px;line-height:1.55">' + paragraphs.map(t=>'<p>'+esc_(t)+'</p>').join('') +
    '<p style="margin:28px 0"><a style="display:inline-block;background:#d80035;color:#fff;text-decoration:none;padding:13px 22px;border-radius:9px;font-weight:bold" href="'+esc_(link)+'">'+esc_(cta)+'</a></p></div></div></div>';
  MailApp.sendEmail({to,subject,body:[heading,...paragraphs,cta+': '+link].join('\n\n'),htmlBody:html,name:'Tư vấn giải pháp Viettel'});
}

function verifiedUrl_(value, hosts) {
  const url = String(value || '').trim();
  const match = /^https:\/\/([a-z0-9.-]+)(?:[/?#][^\s"'<>]*)?$/i.exec(url);
  return match && (!hosts || hosts.test(match[1])) ? url : '';
}
function esc_(v) {
  return String(v).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch]);
}
function cell_(v) { return /^[=+\-@]/.test(v) ? "'" + v : v; }
function tab_(book,name,headers) {
  const sheet = book.getSheetByName(name) || book.insertSheet(name);
  if (!sheet.getLastRow()) sheet.appendRow(headers);
  sheet.setFrozenRows(1);
  sheet.getRange(1,1,1,headers.length).setBackground('#a8002b').setFontColor('#ffffff').setFontWeight('bold');
  return sheet;
}
function rows_(sheet,width) {
  return sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,width).getValues() : [];
}
